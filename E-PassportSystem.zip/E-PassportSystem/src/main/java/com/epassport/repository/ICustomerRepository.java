package com.epassport.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.epassport.entity.Customer;

@Repository
public interface ICustomerRepository extends JpaRepository<Customer, Integer>{
	
	Customer findByContactNo(String contactNo);
	Customer findByCustName(String name);

}
